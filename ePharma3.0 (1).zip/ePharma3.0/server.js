
const express = require("express");
const mysql = require("mysql2/promise");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Serve E-Pharma frontend files
app.use(express.static(__dirname));

// MySQL connection pool
const db = mysql.createPool({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    database: process.env.DB_NAME || "epharma_db",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Test server
app.get("/api", (req, res) => {
    res.json({
        message: "E-Pharma API is running!"
    });
});

// Test MySQL connection
app.get("/api/test-db", async (req, res) => {
    try {
        const [rows] = await db.query("SELECT 1 AS result");

        res.json({
            success: true,
            message: "MySQL connected successfully!",
            result: rows[0].result
        });
    } catch (error) {
        console.error("Database error:", error.message);

        res.status(500).json({
            success: false,
            message: "Database connection failed. Check your .env settings."
        });
    }
});


/* ===== MEDICINES API ===== */

// Get all medicines
app.get("/api/medicines", async (req, res) => {
    try {
        const [rows] = await db.query(
            "SELECT * FROM medicines ORDER BY medicine_id DESC"
        );

        res.json(rows);
    } catch (error) {
        console.error("Get medicines error:", error.message);
        res.status(500).json({
            message: "Unable to retrieve medicines."
        });
    }
});

// Add a medicine
app.post("/api/medicines", async (req, res) => {
    try {
        const {
            medicine_name,
            category,
            price,
            quantity,
            reorder_level,
            expiry_date,
            batch_number
        } = req.body;

        if (
            !medicine_name ||
            price === undefined ||
            quantity === undefined ||
            Number(price) < 0 ||
            Number(quantity) < 0 ||
            !Number.isFinite(Number(price)) ||
            !Number.isInteger(Number(quantity))
        ) {
            return res.status(400).json({
                message: "Please provide valid medicine details."
            });
        }

        const [result] = await db.query(
            `INSERT INTO medicines
            (medicine_name, category, price, quantity,
             reorder_level, expiry_date, batch_number)
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                medicine_name.trim(),
                category || null,
                Number(price),
                Number(quantity),
                Number(reorder_level ?? 10),
                expiry_date || null,
                batch_number || null
            ]
        );

        res.status(201).json({
            message: "Medicine added successfully.",
            medicine_id: result.insertId
        });
    } catch (error) {
        console.error("Add medicine error:", error.message);
        res.status(500).json({
            message: "Unable to add medicine."
        });
    }
});

// Update a medicine
app.put("/api/medicines/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const {
            medicine_name,
            category,
            price,
            quantity,
            reorder_level,
            expiry_date,
            batch_number
        } = req.body;

        if (
            !medicine_name ||
            price === undefined ||
            quantity === undefined ||
            Number(price) < 0 ||
            Number(quantity) < 0 ||
            !Number.isFinite(Number(price)) ||
            !Number.isInteger(Number(quantity))
        ) {
            return res.status(400).json({
                message: "Please provide valid medicine details."
            });
        }

        const [result] = await db.query(
            `UPDATE medicines
             SET medicine_name = ?, category = ?, price = ?,
                 quantity = ?, reorder_level = ?, expiry_date = ?,
                 batch_number = ?
             WHERE medicine_id = ?`,
            [
                medicine_name.trim(),
                category || null,
                Number(price),
                Number(quantity),
                Number(reorder_level ?? 10),
                expiry_date || null,
                batch_number || null,
                id
            ]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Medicine not found."
            });
        }

        res.json({ message: "Medicine updated successfully." });
    } catch (error) {
        console.error("Update medicine error:", error.message);
        res.status(500).json({
            message: "Unable to update medicine."
        });
    }
});

// Delete a medicine
app.delete("/api/medicines/:id", async (req, res) => {
    try {
        const [result] = await db.query(
            "DELETE FROM medicines WHERE medicine_id = ?",
            [req.params.id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Medicine not found."
            });
        }

        res.json({ message: "Medicine deleted successfully." });
    } catch (error) {
        console.error("Delete medicine error:", error.message);
        res.status(500).json({
            message: "Unable to delete medicine. It may have related sales or purchases."
        });
    }
});


/* ===== SALES API ===== */

// Get sales history
app.get("/api/sales", async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                s.sale_id,
                s.total_amount,
                s.sale_date,
                si.medicine_id,
                m.medicine_name,
                si.quantity,
                si.unit_price,
                si.subtotal
            FROM sales s
            JOIN sale_items si ON si.sale_id = s.sale_id
            JOIN medicines m ON m.medicine_id = si.medicine_id
            ORDER BY s.sale_id DESC
        `);

        res.json(rows);
    } catch (error) {
        console.error("Get sales error:", error.message);
        res.status(500).json({
            message: "Unable to retrieve sales."
        });
    }
});

// Create a sale and deduct stock safely
app.post("/api/sales", async (req, res) => {
    const connection = await db.getConnection();

    try {
        const { medicine_id, quantity } = req.body;
        const medicineId = Number(medicine_id);
        const qty = Number(quantity);

        if (
            !Number.isInteger(medicineId) ||
            medicineId <= 0 ||
            !Number.isInteger(qty) ||
            qty <= 0
        ) {
            return res.status(400).json({
                message: "Enter a valid medicine and quantity."
            });
        }

        await connection.beginTransaction();

        const [medicines] = await connection.query(
            "SELECT * FROM medicines WHERE medicine_id = ? FOR UPDATE",
            [medicineId]
        );

        if (medicines.length === 0) {
            await connection.rollback();
            return res.status(404).json({
                message: "Medicine not found."
            });
        }

        const medicine = medicines[0];

        if (medicine.quantity < qty) {
            await connection.rollback();
            return res.status(400).json({
                message: "Not enough stock available."
            });
        }

        const unitPrice = Number(medicine.price);
        const subtotal = Number((unitPrice * qty).toFixed(2));

        const [saleResult] = await connection.query(
            "INSERT INTO sales (total_amount) VALUES (?)",
            [subtotal]
        );

        await connection.query(
            `INSERT INTO sale_items
             (sale_id, medicine_id, quantity, unit_price, subtotal)
             VALUES (?, ?, ?, ?, ?)`,
            [saleResult.insertId, medicineId, qty, unitPrice, subtotal]
        );

        await connection.query(
            `UPDATE medicines
             SET quantity = quantity - ?
             WHERE medicine_id = ?`,
            [qty, medicineId]
        );

        await connection.commit();

        res.status(201).json({
            message: "Sale completed successfully.",
            sale_id: saleResult.insertId,
            total_amount: subtotal
        });
    } catch (error) {
        await connection.rollback();

        console.error("Create sale error:", error.message);

        res.status(500).json({
            message: "Unable to complete sale."
        });
    } finally {
        connection.release();
    }
});


/* ===== PURCHASES API ===== */

// Get purchase records
app.get("/api/purchases", async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                p.purchase_id,
                p.supplier_id,
                p.total_cost,
                p.purchase_date,
                p.status,
                pi.medicine_id,
                m.medicine_name,
                pi.quantity,
                pi.unit_cost,
                pi.subtotal,
                s.supplier_name
            FROM purchases p
            JOIN purchase_items pi ON pi.purchase_id = p.purchase_id
            JOIN medicines m ON m.medicine_id = pi.medicine_id
            LEFT JOIN suppliers s ON s.supplier_id = p.supplier_id
            ORDER BY p.purchase_id DESC
        `);

        res.json(rows);
    } catch (error) {
        console.error("Get purchases error:", error.message);
        res.status(500).json({
            message: "Unable to retrieve purchases."
        });
    }
});

// Create purchase; stock is not changed until Received
app.post("/api/purchases", async (req, res) => {
    const connection = await db.getConnection();

    try {
        const {
            medicine_id,
            supplier_name,
            quantity,
            unit_cost
        } = req.body;

        const medicineId = Number(medicine_id);
        const qty = Number(quantity);
        const cost = Number(unit_cost);
        const supplierName = String(supplier_name || "").trim();

        if (
            !Number.isInteger(medicineId) || medicineId <= 0 ||
            !Number.isInteger(qty) || qty <= 0 ||
            !Number.isFinite(cost) || cost <= 0 ||
            !supplierName
        ) {
            return res.status(400).json({
                message: "Enter valid purchase details."
            });
        }

        await connection.beginTransaction();

        const [medicines] = await connection.query(
            "SELECT medicine_id FROM medicines WHERE medicine_id = ? FOR UPDATE",
            [medicineId]
        );

        if (medicines.length === 0) {
            await connection.rollback();
            return res.status(404).json({
                message: "Medicine not found."
            });
        }

        // Find existing supplier or create one.
        const [suppliers] = await connection.query(
            "SELECT supplier_id FROM suppliers WHERE supplier_name = ? LIMIT 1",
            [supplierName]
        );

        let supplierId;

        if (suppliers.length > 0) {
            supplierId = suppliers[0].supplier_id;
        } else {
            const [supplierResult] = await connection.query(
                "INSERT INTO suppliers (supplier_name) VALUES (?)",
                [supplierName]
            );

            supplierId = supplierResult.insertId;
        }

        const total = Number((qty * cost).toFixed(2));

        const [purchaseResult] = await connection.query(
            "INSERT INTO purchases (supplier_id, total_cost, status) VALUES (?, ?, 'Pending')",
            [supplierId, total]
        );

        await connection.query(
            `INSERT INTO purchase_items
             (purchase_id, medicine_id, quantity, unit_cost, subtotal)
             VALUES (?, ?, ?, ?, ?)`,
            [purchaseResult.insertId, medicineId, qty, cost, total]
        );

        await connection.commit();

        res.status(201).json({
            message: "Purchase saved as Pending.",
            purchase_id: purchaseResult.insertId
        });
    } catch (error) {
        await connection.rollback();
        console.error("Create purchase error:", error.message);

        res.status(500).json({
            message: "Unable to save purchase."
        });
    } finally {
        connection.release();
    }
});

// Change purchase status to Received and add stock once
app.patch("/api/purchases/:id/receive", async (req, res) => {
    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        const [purchases] = await connection.query(
            "SELECT purchase_id, status FROM purchases WHERE purchase_id = ? FOR UPDATE",
            [req.params.id]
        );

        if (purchases.length === 0) {
            await connection.rollback();
            return res.status(404).json({
                message: "Purchase not found."
            });
        }

        if (purchases[0].status !== "Pending") {
            await connection.rollback();
            return res.status(400).json({
                message: "Only Pending purchases can be received."
            });
        }

        const [items] = await connection.query(
            "SELECT medicine_id, quantity FROM purchase_items WHERE purchase_id = ?",
            [req.params.id]
        );

        for (const item of items) {
            await connection.query(
                "UPDATE medicines SET quantity = quantity + ? WHERE medicine_id = ?",
                [item.quantity, item.medicine_id]
            );
        }

        await connection.query(
            "UPDATE purchases SET status = 'Received' WHERE purchase_id = ?",
            [req.params.id]
        );

        await connection.commit();

        res.json({
            message: "Purchase received and stock updated."
        });
    } catch (error) {
        await connection.rollback();
        console.error("Receive purchase error:", error.message);

        res.status(500).json({
            message: "Unable to receive purchase."
        });
    } finally {
        connection.release();
    }
});

app.get("/api/suppliers", async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT *
            FROM suppliers
            ORDER BY supplier_id DESC
        `);

        res.json(rows);
    } catch (error) {
        console.error("Load suppliers error:", error);
        res.status(500).json({
            message: "Failed to load suppliers."
        });
    }
});

app.post("/api/suppliers", async (req, res) => {
    try {
        const {
            supplier_name,
            contact_person,
            phone,
            email,
            address,
            status
        } = req.body;

        if (!supplier_name || !supplier_name.trim()) {
            return res.status(400).json({
                message: "Supplier name is required."
            });
        }

        const [result] = await db.query(
            `INSERT INTO suppliers
            (supplier_name, contact_person, phone, email, address, status)
            VALUES (?, ?, ?, ?, ?, ?)`,
            [
                supplier_name.trim(),
                contact_person || "",
                phone || "",
                email || "",
                address || "",
                status || "Active"
            ]
        );

        res.status(201).json({
            success: true,
            message: "Supplier added successfully!",
            supplier_id: result.insertId
        });
    } catch (error) {
        console.error("Add supplier error:", error);
        res.status(500).json({
            message: "Failed to add supplier."
        });
    }
});

app.put("/api/suppliers/:id", async (req, res) => {
    try {
        const {
            supplier_name,
            contact_person,
            phone,
            email,
            address,
            status
        } = req.body;

        if (!supplier_name || !supplier_name.trim()) {
            return res.status(400).json({
                message: "Supplier name is required."
            });
        }

        const [result] = await db.query(
            `UPDATE suppliers
             SET supplier_name = ?,
                 contact_person = ?,
                 phone = ?,
                 email = ?,
                 address = ?,
                 status = ?
             WHERE supplier_id = ?`,
            [
                supplier_name.trim(),
                contact_person || "",
                phone || "",
                email || "",
                address || "",
                status || "Active",
                req.params.id
            ]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Supplier not found."
            });
        }

        res.json({
            success: true,
            message: "Supplier updated successfully!"
        });
    } catch (error) {
        console.error("Update supplier error:", error);
        res.status(500).json({
            message: "Failed to update supplier."
        });
    }
});

app.delete("/api/suppliers/:id", async (req, res) => {
    try {
        const [result] = await db.query(
            "DELETE FROM suppliers WHERE supplier_id = ?",
            [req.params.id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Supplier not found."
            });
        }

        res.json({
            success: true,
            message: "Supplier deleted successfully!"
        });
    } catch (error) {
        console.error("Delete supplier error:", error);

        res.status(500).json({
            message: "Unable to delete supplier. It may be linked to existing purchases."
        });
    }
});


// Start server
app.listen(PORT, () => {
    console.log(`E-Pharma server running at http://localhost:${PORT}`);
});

process.on("SIGINT", async () => {
    await db.end();
    process.exit(0);
});
